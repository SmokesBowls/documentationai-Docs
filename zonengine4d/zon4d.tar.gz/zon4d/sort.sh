#!/bin/bash

# Create directories
mkdir -p ZW-S ZW-H ZON4D TEMPORAL META

# Log file
LOG="sort_log.txt"
echo "==== SORT RUN $(date) ====" >> $LOG

move() {
    if [ -f "$1" ]; then
        echo "Moving: $1 -> $2" | tee -a $LOG
        mv "$1" "$2/"
    fi
}

######## ZW-S ########
move "03_ZW-S_SPEC_v1.0.txt" ZW-S
move "ZW-S Specification (Soft ZW Language) (1).txt" ZW-S

######## ZW-H ########
move "05_ZW-H_SPEC_v0.1_SECTION_1_TYPES.txt" ZW-H
move "ZW-H SPEC v0.1 — SECTION 1 TYPES (FINAL)_1.txt" ZW-H
move "ZW_H_SPEC_v0.1_SECTION_1_TYPES.txt" ZW-H
move "ZW_H_OVERRIDE_MODEL.txt" ZW-H
move "ZW-H_SECTION_5_PRE-SPEC_PROMPT.txt" ZW-H
move "ZW-H_SPEC_v0.1_SECTION_5_MAPPING_PROMPT.txt" ZW-H
move "ZW_H_Transition_Dialogue.txt" ZW-H
move "ZW_H_v0.1_Quick_Refresher.txt" ZW-H
move "Generate ZW-H Spec v0.1 (Hard ZW Schema Language).txt" ZW-H
move "Appendix C1 — Override Handling Performance Spec.txt" ZW-H

######## ZON4D ########
move "ZON4D_SPEC_v0.1.txt" ZON4D
move "ZON4D_Temporal_Law_v1.0.zwdoc.txt" ZON4D
move "24 — Oracle Law - ZON4D-AP-Kernal enforcement.txt" ZON4D
move "Ap-ZON4D Integration Supplement tc state binding layer.txt" ZON4D
move "Cross-Domain Conflict Resolution (AP-ZON4D).txt" ZON4D
move "Predictive Sandbox & Temporal Query Isolation..txt" ZON4D
move "Appendix B — ZON4D v0.1 Specification.txt" ZON4D
move "SECTION 23-Temporal Query Protocol Micro-Spec, including.txt" ZON4D
move "SECTION 20 — AP Hooks on ZON4D.txt" ZON4D
move "SECTION 22 - Scene_Track Engine.txt" ZON4D
move "SECTION 13 — Dialogue Intensity Tracks.txt" ZON4D
move "SECTION 18 — Facial Animation & Visemes.txt" ZON4D
move "SECTION 19- Audio Envelopes.txt" ZON4D
move "Appendix A — Temporal Data Model.txt" ZON4D
move "SECTION 31 — Temporal Syncpoints & Hash Anchors.txt" ZON4D
move "SECTION 32 — Canonical Hashing Rules (HASH32 Spec) .txt" ZON4D
move "SECTION 33 — Snapshot Diff & Drift Metrics .txt" ZON4D
move "SECTION_34_SNAPSHOT_MERGE_PROTOCOL.txt" ZON4D
move "34 – Temporal Snapshot Consolidation Layer.txt" ZON4D
move "SECTION 34 Temporal Snapshot Consolidation Layer (TSCL).txt" ZON4D
move "SECTION_34_TEMPORAL_SNAPSHOT_CONSOLIDATION_LAYER.txt.txt" ZON4D
move "35.txt" ZON4D
move "36.txt" ZON4D
move "37.txt" ZON4D
move "38.txt" ZON4D
move "39 – Temporal Deltas & Patch Propagation.txt" ZON4D
move "39.txt" ZON4D
move "40.txt" ZON4D
move "41.2 (1).txt" ZON4D
move "43.txt" ZON4D
move "49-TEMPORAL LOCKSTEP ABI (.txt" ZON4D
move "4D STATE COMPRESSION & DELTA PACKING (ZONB v2).txt" ZON4D

######## TEMPORAL ########
move "TEMPORAL ANCHORS (Soft, Hard, Immutable).txt" TEMPORAL
move "TEMPORAL ENTROPY & DRIFT STABILIZATION  (ZON4D Temporal Law, Part VI).txt" TEMPORAL
move "Temporal Error Surfaces & Discontinuity Zones.txt" TEMPORAL
move "TEMPORAL INVALIDATION & CACHE PURGE RULES.txt" TEMPORAL
move "Temporal Merge & Retcon Rules.txt" TEMPORAL
move "Temporal Topology & Multi-Track Synchronization.txt" TEMPORAL

######## META ########
move "META_ZWH_BLUEPRINT_PHASE_LOCK.txt" META
move "APPENDIX D — Author Notes_Development map.txt" META
move "CURRENT STATUS SAFE SPEC PHASE.txt" META
move "CURRENT STATUS SAFE SPEC PHASE (1).txt" META
move "25 again.txt" META
move "25 clarification options.txt" META
move "25 continued.txt" META
move "30 (1).txt" META
move "section 24.txt" META
move "7.6 — Forbidden in Output (THIS file) 7.7 — Performance Contract (.txt" META

echo "==== SORT COMPLETE ====" >> $LOG
echo "Done!"
