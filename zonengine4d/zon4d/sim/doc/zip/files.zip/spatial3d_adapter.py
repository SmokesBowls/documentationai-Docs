# zonengine4d/zon4d/sim/spatial3d_adapter.py
"""
SPATIAL3D_ADAPTER: Glue between deep contract and mr kernel.
Maintains canonical AP constraints, delegates physics to mr.
"""

import time
from typing import Dict, List, Any, Tuple

from spatial3d import Spatial3DStateView, spatial3d_no_overlap_constraint, Alert
from spatial3d_mr import step_spatial3d, SpatialAlert


class APViolation(Exception):
    """Signal AP constraint violation - triggers rollback."""
    pass


class Spatial3DStateViewAdapter(Spatial3DStateView):
    """
    Adapter that bridges deep contract with mr kernel.
    Preserves AP constraints as canonical validation layer.
    """
    
    def __init__(self, state_slice: dict):
        super().__init__(state_slice)
        self._mr_deltas: List[Dict[str, Any]] = []
        self._delta_counter = 0
    
    def handle_delta(self, delta_type: str, payload: dict) -> Tuple[bool, List[Alert]]:
        """Convert deep deltas to mr format with AP pre-validation."""
        success, alerts = super().handle_delta(delta_type, payload)
        if not success:
            return False, alerts
        
        # Convert deep delta → mr delta
        mr_delta = self._convert_to_mr(delta_type, payload)
        if mr_delta:
            self._mr_deltas.append(mr_delta)
        
        return True, alerts
    
    def physics_step(self, delta_time: float) -> List[Alert]:
        """
        Execute physics step via mr kernel, then validate AP constraints.
        If AP fails, signal rollback.
        """
        if not self._mr_deltas and delta_time == 0:
            return []
        
        # 1. Run mr kernel
        snapshot_in = {"spatial3d": self._state_slice}
        snapshot_out, accepted, mr_alerts = step_spatial3d(
            snapshot_in, self._mr_deltas, delta_time
        )
        
        # 2. Update state from mr output
        old_state = self._state_slice
        self._state_slice = snapshot_out["spatial3d"]
        
        # 3. Clear processed deltas
        self._mr_deltas.clear()
        
        # 4. Validate AP constraints (CANONICAL VALIDATION LAYER)
        valid, msg = spatial3d_no_overlap_constraint({"spatial3d": self._state_slice})
        if not valid:
            # ROLLBACK: Restore old state and signal violation
            self._state_slice = old_state
            raise APViolation(f"Spatial3D AP violation: {msg}")
        
        # 5. Convert mr alerts to runtime alerts
        runtime_alerts = []
        for mr_alert in mr_alerts:
            runtime_alerts.append(Alert(
                level=mr_alert.level,
                step=0,
                message=f"[SPATIAL3D] {mr_alert.code}: {mr_alert.message}",
                tick=0,
                ts=time.time(),
                payload={"entity_ids": mr_alert.entity_ids}
            ))
        
        return runtime_alerts
    
    def _convert_to_mr(self, deep_type: str, payload: dict) -> Dict[str, Any]:
        """Convert deep delta format to mr delta format."""
        self._delta_counter += 1
        delta_id = f"spatial_{deep_type}_{self._delta_counter}"
        
        if deep_type == "spatial3d/spawn":
            return {
                "id": delta_id,
                "type": "spatial/spawn",
                "payload": {
                    "entity_id": payload["entity_id"],
                    "entity": {
                        "pos": payload.get("pos", (0, 0, 0)),
                        "radius": payload.get("radius", 0.5),
                        "solid": payload.get("solid", True),
                        "tags": payload.get("tags", []),
                    }
                }
            }
        
        elif deep_type == "spatial3d/move":
            # Convert movement request to impulse
            entity_id = payload["entity_id"]
            target = payload["target_pos"]
            speed = payload.get("speed", 5.0)
            
            # Calculate direction and impulse
            # (In reality, you'd look up current position from state)
            return {
                "id": delta_id,
                "type": "spatial/apply_impulse",
                "payload": {
                    "entity_id": entity_id,
                    "impulse": (speed, 0, 0),  # Simplified
                    "mass": 1.0,
                }
            }
        
        return None
